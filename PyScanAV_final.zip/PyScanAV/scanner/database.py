def load_signatures():
    # Example simple virus signatures (strings or hashes)
    return {
        "badvirus": "FakeVirus",
        "evil123": "EvilVirus",
        "malware_signature": "MalwareX"
    }
